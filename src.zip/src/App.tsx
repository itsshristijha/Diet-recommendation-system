import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Login from './components/Login';
import LifestyleForm from './components/LifestyleForm';
import HealthForm from './components/HealthForm';
import PreferencesForm from './components/PreferencesForm';
import HealthReport from './components/HealthReport';
import Recommendations from './components/Recommendations';
import RecipeModifier from './components/RecipeModifier';

function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<Login />} />
            <Route path="/lifestyle" element={<LifestyleForm />} />
            <Route path="/health" element={<HealthForm />} />
            <Route path="/preferences" element={<PreferencesForm />} />
            <Route path="/health-report" element={<HealthReport />} />
            <Route path="/recommendations" element={<Recommendations />} />
            <Route path="/recipe-modifier" element={<RecipeModifier />} />
          </Routes>
        </div>
      </div>
    </BrowserRouter>
  );
}

export default App;