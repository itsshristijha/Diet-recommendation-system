import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { HealthData } from '../types';

const HealthForm = () => {
  const navigate = useNavigate();
  const [healthData, setHealthData] = useState<HealthData>({
    height: 170,
    weight: 70,
    allergies: [],
    medicalConditions: [],
  });
  const [newAllergy, setNewAllergy] = useState('');
  const [newCondition, setNewCondition] = useState('');

  const calculateBMI = () => {
    const heightInMeters = healthData.height / 100;
    return (healthData.weight / (heightInMeters * heightInMeters)).toFixed(1);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    navigate('/preferences');
  };

  const addAllergy = () => {
    if (newAllergy && !healthData.allergies.includes(newAllergy)) {
      setHealthData({ ...healthData, allergies: [...healthData.allergies, newAllergy] });
      setNewAllergy('');
    }
  };

  const addCondition = () => {
    if (newCondition && !healthData.medicalConditions.includes(newCondition)) {
      setHealthData({ ...healthData, medicalConditions: [...healthData.medicalConditions, newCondition] });
      setNewCondition('');
    }
  };

  return (
    <div className="max-w-md mx-auto bg-white rounded-xl shadow-md overflow-hidden md:max-w-2xl p-8">
      <h2 className="text-2xl font-bold text-center text-gray-800 mb-8">Health Assessment</h2>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700">Height (cm)</label>
          <input
            type="number"
            required
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
            value={healthData.height}
            onChange={(e) => setHealthData({ ...healthData, height: parseInt(e.target.value) })}
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Weight (kg)</label>
          <input
            type="number"
            required
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
            value={healthData.weight}
            onChange={(e) => setHealthData({ ...healthData, weight: parseInt(e.target.value) })}
          />
        </div>
        <div className="bg-gray-50 p-4 rounded-md">
          <p className="text-sm font-medium text-gray-700">Your BMI: {calculateBMI()}</p>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Allergies</label>
          <div className="flex space-x-2 mb-2">
            <input
              type="text"
              className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
              value={newAllergy}
              onChange={(e) => setNewAllergy(e.target.value)}
              placeholder="Add allergy"
            />
            <button
              type="button"
              onClick={addAllergy}
              className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
            >
              Add
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {healthData.allergies.map((allergy, index) => (
              <span key={index} className="bg-green-100 text-green-800 px-2 py-1 rounded-md text-sm">
                {allergy}
              </span>
            ))}
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Medical Conditions</label>
          <div className="flex space-x-2 mb-2">
            <input
              type="text"
              className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
              value={newCondition}
              onChange={(e) => setNewCondition(e.target.value)}
              placeholder="Add medical condition"
            />
            <button
              type="button"
              onClick={addCondition}
              className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
            >
              Add
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {healthData.medicalConditions.map((condition, index) => (
              <span key={index} className="bg-green-100 text-green-800 px-2 py-1 rounded-md text-sm">
                {condition}
              </span>
            ))}
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Upload Health Report</label>
          <input
            type="file"
            accept=".pdf,.jpg,.png"
            className="mt-1 block w-full text-sm text-gray-500
              file:mr-4 file:py-2 file:px-4
              file:rounded-md file:border-0
              file:text-sm file:font-semibold
              file:bg-green-50 file:text-green-700
              hover:file:bg-green-100"
          />
        </div>
        <button
          type="submit"
          className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
        >
          Continue to Food Preferences
        </button>
      </form>
    </div>
  );
};

export default HealthForm;