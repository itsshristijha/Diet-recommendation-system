import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertTriangle, CheckCircle, FileText } from 'lucide-react';

const HealthReport = () => {
  const navigate = useNavigate();
  const [analysis, setAnalysis] = useState({
    status: 'processing',
    risks: [],
    recommendations: []
  });

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Simulate report analysis
      setTimeout(() => {
        setAnalysis({
          status: 'completed',
          risks: ['High cholesterol', 'Vitamin D deficiency'],
          recommendations: [
            'Schedule regular check-ups',
            'Consider vitamin D supplementation',
            'Monitor cholesterol levels'
          ]
        });
      }, 2000);
    }
  };

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-md overflow-hidden p-8">
      <h2 className="text-2xl font-bold text-center text-gray-800 mb-8">Health Report Analysis</h2>
      
      <div className="mb-8">
        <div className="flex items-center justify-center w-full">
          <label className="flex flex-col items-center justify-center w-full h-64 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100">
            <div className="flex flex-col items-center justify-center pt-5 pb-6">
              <FileText className="w-12 h-12 mb-4 text-gray-500" />
              <p className="mb-2 text-sm text-gray-500">
                <span className="font-semibold">Click to upload</span> or drag and drop
              </p>
              <p className="text-xs text-gray-500">PDF, JPG, or PNG (MAX. 10MB)</p>
            </div>
            <input
              type="file"
              className="hidden"
              accept=".pdf,.jpg,.png"
              onChange={handleFileUpload}
            />
          </label>
        </div>
      </div>

      {analysis.status === 'completed' && (
        <div className="space-y-6">
          <div className="bg-yellow-50 p-4 rounded-lg">
            <div className="flex items-center mb-4">
              <AlertTriangle className="h-6 w-6 text-yellow-600 mr-2" />
              <h3 className="text-lg font-medium text-yellow-800">Potential Health Risks</h3>
            </div>
            <ul className="list-disc pl-5 space-y-2">
              {analysis.risks.map((risk, index) => (
                <li key={index} className="text-yellow-700">{risk}</li>
              ))}
            </ul>
          </div>

          <div className="bg-green-50 p-4 rounded-lg">
            <div className="flex items-center mb-4">
              <CheckCircle className="h-6 w-6 text-green-600 mr-2" />
              <h3 className="text-lg font-medium text-green-800">Medical Recommendations</h3>
            </div>
            <ul className="list-disc pl-5 space-y-2">
              {analysis.recommendations.map((rec, index) => (
                <li key={index} className="text-green-700">{rec}</li>
              ))}
            </ul>
          </div>

          <button
            onClick={() => navigate('/recommendations')}
            className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
          >
            View Diet Recommendations
          </button>
        </div>
      )}
    </div>
  );
};

export default HealthReport;