import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { LifestyleData } from '../types';

const LifestyleForm = () => {
  const navigate = useNavigate();
  const [lifestyleData, setLifestyleData] = useState<LifestyleData>({
    sleepHours: 7,
    exerciseFrequency: 'moderate',
    dietType: 'balanced',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    navigate('/health');
  };

  return (
    <div className="max-w-md mx-auto bg-white rounded-xl shadow-md overflow-hidden md:max-w-2xl p-8">
      <h2 className="text-2xl font-bold text-center text-gray-800 mb-8">Lifestyle Assessment</h2>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700">Average Sleep Hours</label>
          <input
            type="number"
            min="0"
            max="24"
            required
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
            value={lifestyleData.sleepHours}
            onChange={(e) => setLifestyleData({ ...lifestyleData, sleepHours: parseInt(e.target.value) })}
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Exercise Frequency</label>
          <select
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
            value={lifestyleData.exerciseFrequency}
            onChange={(e) => setLifestyleData({ ...lifestyleData, exerciseFrequency: e.target.value })}
          >
            <option value="sedentary">Sedentary (Little to no exercise)</option>
            <option value="light">Light (1-3 days/week)</option>
            <option value="moderate">Moderate (3-5 days/week)</option>
            <option value="active">Active (6-7 days/week)</option>
            <option value="very_active">Very Active (Professional athlete)</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Current Diet Type</label>
          <select
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
            value={lifestyleData.dietType}
            onChange={(e) => setLifestyleData({ ...lifestyleData, dietType: e.target.value })}
          >
            <option value="balanced">Balanced</option>
            <option value="vegetarian">Vegetarian</option>
            <option value="vegan">Vegan</option>
            <option value="keto">Keto</option>
            <option value="paleo">Paleo</option>
            <option value="mediterranean">Mediterranean</option>
          </select>
        </div>
        <button
          type="submit"
          className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
        >
          Continue to Health Assessment
        </button>
      </form>
    </div>
  );
};

export default LifestyleForm;