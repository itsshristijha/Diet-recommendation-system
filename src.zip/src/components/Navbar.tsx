import React from 'react';
import { Link } from 'react-router-dom';
import { Salad } from 'lucide-react';

const Navbar = () => {
  return (
    <nav className="bg-white shadow-lg">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-3">
            <Salad className="h-8 w-8 text-green-600" />
            <span className="text-xl font-bold text-gray-800">NutriGuide</span>
          </Link>
          <div className="hidden md:flex space-x-8">
            <Link to="/lifestyle" className="text-gray-600 hover:text-green-600">Lifestyle</Link>
            <Link to="/health" className="text-gray-600 hover:text-green-600">Health</Link>
            <Link to="/preferences" className="text-gray-600 hover:text-green-600">Preferences</Link>
            <Link to="/recommendations" className="text-gray-600 hover:text-green-600">Recommendations</Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;