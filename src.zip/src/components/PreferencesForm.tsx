import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FoodPreferences } from '../types';

const PreferencesForm = () => {
  const navigate = useNavigate();
  const [preferences, setPreferences] = useState<FoodPreferences>({
    cuisine: [],
    restrictions: [],
    favoriteIngredients: []
  });
  const [newItem, setNewItem] = useState({
    cuisine: '',
    restriction: '',
    ingredient: ''
  });

  const cuisineOptions = [
    'Italian', 'Indian', 'Chinese', 'Japanese', 'Mexican',
    'Mediterranean', 'Thai', 'French', 'Greek', 'Korean'
  ];

  const addCuisine = (cuisine: string) => {
    if (!preferences.cuisine.includes(cuisine)) {
      setPreferences({
        ...preferences,
        cuisine: [...preferences.cuisine, cuisine]
      });
    }
  };

  const addRestriction = () => {
    if (newItem.restriction && !preferences.restrictions.includes(newItem.restriction)) {
      setPreferences({
        ...preferences,
        restrictions: [...preferences.restrictions, newItem.restriction]
      });
      setNewItem({ ...newItem, restriction: '' });
    }
  };

  const addIngredient = () => {
    if (newItem.ingredient && !preferences.favoriteIngredients.includes(newItem.ingredient)) {
      setPreferences({
        ...preferences,
        favoriteIngredients: [...preferences.favoriteIngredients, newItem.ingredient]
      });
      setNewItem({ ...newItem, ingredient: '' });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    navigate('/health-report');
  };

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-md overflow-hidden p-8">
      <h2 className="text-2xl font-bold text-center text-gray-800 mb-8">Food Preferences</h2>
      <form onSubmit={handleSubmit} className="space-y-8">
        <div>
          <label className="block text-lg font-medium text-gray-700 mb-4">Preferred Cuisines</label>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-4">
            {cuisineOptions.map((cuisine) => (
              <button
                key={cuisine}
                type="button"
                onClick={() => addCuisine(cuisine)}
                className={`p-2 rounded-md text-sm ${
                  preferences.cuisine.includes(cuisine)
                    ? 'bg-green-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {cuisine}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-lg font-medium text-gray-700 mb-4">Dietary Restrictions</label>
          <div className="flex space-x-2 mb-3">
            <input
              type="text"
              className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
              placeholder="Add restriction (e.g., gluten-free)"
              value={newItem.restriction}
              onChange={(e) => setNewItem({ ...newItem, restriction: e.target.value })}
            />
            <button
              type="button"
              onClick={addRestriction}
              className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
            >
              Add
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {preferences.restrictions.map((restriction, index) => (
              <span key={index} className="bg-red-100 text-red-800 px-3 py-1 rounded-full text-sm">
                {restriction}
              </span>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-lg font-medium text-gray-700 mb-4">Favorite Ingredients</label>
          <div className="flex space-x-2 mb-3">
            <input
              type="text"
              className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
              placeholder="Add ingredient"
              value={newItem.ingredient}
              onChange={(e) => setNewItem({ ...newItem, ingredient: e.target.value })}
            />
            <button
              type="button"
              onClick={addIngredient}
              className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
            >
              Add
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {preferences.favoriteIngredients.map((ingredient, index) => (
              <span key={index} className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
                {ingredient}
              </span>
            ))}
          </div>
        </div>

        <button
          type="submit"
          className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
        >
          Continue to Health Report Analysis
        </button>
      </form>
    </div>
  );
};

export default PreferencesForm;