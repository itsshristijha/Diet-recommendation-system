import React, { useState } from 'react';
import { ChefHat, AlertCircle } from 'lucide-react';

const RecipeModifier = () => {
  const [recipe, setRecipe] = useState('');
  const [modifiedRecipe, setModifiedRecipe] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    // Simulate API call for recipe modification
    setTimeout(() => {
      const healthyVersion = `Modified Recipe:\n\n${recipe}\n\nHealthy Substitutions:\n- Use olive oil instead of butter\n- Replace white flour with whole wheat flour\n- Add more vegetables\n- Reduce salt by 50%\n- Use natural sweeteners`;
      setModifiedRecipe(healthyVersion);
      setLoading(false);
    }, 1500);
  };

  return (
    <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-md overflow-hidden p-8">
      <div className="flex items-center justify-center mb-8">
        <ChefHat className="h-8 w-8 text-green-600 mr-3" />
        <h2 className="text-2xl font-bold text-gray-800">Recipe Modifier</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <h3 className="text-lg font-medium text-gray-800 mb-4">Enter Your Recipe</h3>
          <form onSubmit={handleSubmit}>
            <textarea
              className="w-full h-64 p-4 border rounded-md shadow-sm focus:ring-green-500 focus:border-green-500"
              placeholder="Paste your recipe here..."
              value={recipe}
              onChange={(e) => setRecipe(e.target.value)}
            ></textarea>
            <button
              type="submit"
              disabled={!recipe || loading}
              className={`mt-4 w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white ${
                !recipe || loading
                  ? 'bg-gray-400 cursor-not-allowed'
                  : 'bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500'
              }`}
            >
              {loading ? 'Modifying Recipe...' : 'Make it Healthy'}
            </button>
          </form>
        </div>

        <div>
          <h3 className="text-lg font-medium text-gray-800 mb-4">Healthy Version</h3>
          {modifiedRecipe ? (
            <div className="bg-green-50 p-4 rounded-md">
              <pre className="whitespace-pre-wrap font-sans text-sm text-gray-700">
                {modifiedRecipe}
              </pre>
            </div>
          ) : (
            <div className="h-64 flex items-center justify-center border-2 border-dashed rounded-md">
              <div className="text-center text-gray-500">
                <AlertCircle className="h-8 w-8 mx-auto mb-2" />
                <p>Modified recipe will appear here</p>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="mt-8 bg-blue-50 p-6 rounded-lg">
        <h3 className="text-lg font-medium text-blue-800 mb-4">Healthy Cooking Tips</h3>
        <ul className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <li className="flex items-start">
            <span className="w-2 h-2 mt-2 rounded-full bg-blue-400 mr-2"></span>
            <p className="text-sm text-gray-700">Use herbs and spices instead of salt for flavoring</p>
          </li>
          <li className="flex items-start">
            <span className="w-2 h-2 mt-2 rounded-full bg-blue-400 mr-2"></span>
            <p className="text-sm text-gray-700">Steam or bake instead of frying</p>
          </li>
          <li className="flex items-start">
            <span className="w-2 h-2 mt-2 rounded-full bg-blue-400 mr-2"></span>
            <p className="text-sm text-gray-700">Include more plant-based proteins</p>
          </li>
          <li className="flex items-start">
            <span className="w-2 h-2 mt-2 rounded-full bg-blue-400 mr-2"></span>
            <p className="text-sm text-gray-700">Choose whole grains over refined grains</p>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default RecipeModifier;