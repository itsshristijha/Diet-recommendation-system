import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Apple, Beef, Fish, Leaf } from 'lucide-react';

const Recommendations = () => {
  const navigate = useNavigate();

  const recommendations = [
    {
      category: 'Proteins',
      icon: <Fish className="h-6 w-6" />,
      items: ['Salmon', 'Lean chicken', 'Tofu'],
      benefits: 'Rich in omega-3 and essential proteins'
    },
    {
      category: 'Vegetables',
      icon: <Leaf className="h-6 w-6" />,
      items: ['Spinach', 'Broccoli', 'Kale'],
      benefits: 'High in vitamins and minerals'
    },
    {
      category: 'Fruits',
      icon: <Apple className="h-6 w-6" />,
      items: ['Berries', 'Citrus fruits', 'Apples'],
      benefits: 'Antioxidants and vitamin C'
    },
    {
      category: 'Avoid',
      icon: <Beef className="h-6 w-6" />,
      items: ['Processed foods', 'High-sugar drinks', 'Excessive salt'],
      benefits: 'Reduce health risks'
    }
  ];

  return (
    <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-md overflow-hidden p-8">
      <h2 className="text-2xl font-bold text-center text-gray-800 mb-8">Your Personalized Diet Recommendations</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        {recommendations.map((rec, index) => (
          <div
            key={index}
            className={`p-6 rounded-lg ${
              rec.category === 'Avoid' ? 'bg-red-50' : 'bg-green-50'
            }`}
          >
            <div className="flex items-center mb-4">
              <div className={`p-2 rounded-full ${
                rec.category === 'Avoid' ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'
              }`}>
                {rec.icon}
              </div>
              <h3 className="ml-3 text-lg font-medium">{rec.category}</h3>
            </div>
            <ul className="space-y-2 mb-4">
              {rec.items.map((item, i) => (
                <li key={i} className="flex items-center">
                  <span className="w-2 h-2 rounded-full bg-gray-400 mr-2"></span>
                  {item}
                </li>
              ))}
            </ul>
            <p className="text-sm text-gray-600">{rec.benefits}</p>
          </div>
        ))}
      </div>

      <div className="bg-blue-50 p-6 rounded-lg mb-8">
        <h3 className="text-lg font-medium text-blue-800 mb-4">Daily Meal Plan Suggestion</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-md shadow-sm">
            <h4 className="font-medium text-gray-800 mb-2">Breakfast</h4>
            <p className="text-sm text-gray-600">Oatmeal with berries and nuts</p>
          </div>
          <div className="bg-white p-4 rounded-md shadow-sm">
            <h4 className="font-medium text-gray-800 mb-2">Lunch</h4>
            <p className="text-sm text-gray-600">Grilled chicken salad with quinoa</p>
          </div>
          <div className="bg-white p-4 rounded-md shadow-sm">
            <h4 className="font-medium text-gray-800 mb-2">Dinner</h4>
            <p className="text-sm text-gray-600">Baked salmon with roasted vegetables</p>
          </div>
        </div>
      </div>

      <button
        onClick={() => navigate('/recipe-modifier')}
        className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
      >
        Customize Recipes
      </button>
    </div>
  );
};

export default Recommendations;