export interface UserData {
  username: string;
  age: number;
  gender: 'male' | 'female' | 'other';
  bloodGroup: string;
  email: string;
}

export interface LifestyleData {
  sleepHours: number;
  exerciseFrequency: string;
  dietType: string;
}

export interface HealthData {
  height: number;
  weight: number;
  allergies: string[];
  medicalConditions: string[];
}

export interface FoodPreferences {
  cuisine: string[];
  restrictions: string[];
  favoriteIngredients: string[];
}